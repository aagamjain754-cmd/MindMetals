import { type FormEvent, type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Check,
  Cpu,
  Factory,
  Layers3,
  Mail,
  MapPin,
  Menu,
  PackageCheck,
  RefreshCcw,
  Recycle,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

function Mark({ inverse = false }: { inverse?: boolean }) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${inverse ? 'text-[#f4f0e6]' : 'text-[#26342c]'}`}>
      <svg aria-hidden="true" viewBox="0 0 42 42" className="h-9 w-9 shrink-0">
        <path d="M21 4 36.6 13v16L21 38 5.4 29V13L21 4Z" fill="none" stroke="currentColor" strokeWidth="2.2" />
        <path d="m12 25.5 5.3-9.3 3.7 6.2 4.2-7.5L31 25.5H12Z" fill="currentColor" />
        <circle cx="29.8" cy="12.2" r="2.1" fill="#d77a51" />
      </svg>
      <span className="font-display text-[1.65rem] font-semibold tracking-[-0.06em]">Mind<span className="text-[#d77a51]">Metals</span></span>
    </span>
  );
}

function SectionLabel({ children, light = false }: { children: ReactNode; light?: boolean }) {
  return (
    <div className={`text-eyebrow flex items-center gap-2 ${light ? 'text-[#a8c9b3]' : 'text-[#d77a51]'}`}>
      <span className="h-px w-7 bg-current" />
      {children}
    </div>
  );
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    const items = document.querySelectorAll('.reveal');
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => entry.isIntersecting && entry.target.classList.add('is-visible')),
      { threshold: 0.12 },
    );
    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, []);

  const closeMenu = () => setMenuOpen(false);
  const submitContact = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSent(true);
  };

  return (
    <main className="overflow-hidden">
      <section id="top" className="relative bg-[#26342c] text-[#f4f0e6]">
        <div className="absolute inset-0 opacity-40 [background-image:linear-gradient(rgba(168,201,179,.09)_1px,transparent_1px),linear-gradient(90deg,rgba(168,201,179,.09)_1px,transparent_1px)] [background-size:60px_60px] [mask-image:linear-gradient(to_bottom,black,transparent_80%)]" />
        <nav className="relative z-20 section-shell flex h-[78px] items-center justify-between border-b border-[#a8c9b3]/20" aria-label="Main navigation">
          <a href="#top" onClick={closeMenu} data-testid="link-brand-home" aria-label="MindMetals home"><Mark inverse /></a>
          <div className="hidden items-center gap-8 md:flex">
            <a href="#process" className="text-sm text-[#c9d4c9] transition-colors hover:text-[#f4f0e6]" data-testid="link-process">Process</a>
            <a href="#materials" className="text-sm text-[#c9d4c9] transition-colors hover:text-[#f4f0e6]" data-testid="link-materials">Materials</a>
            <a href="#impact" className="text-sm text-[#c9d4c9] transition-colors hover:text-[#f4f0e6]" data-testid="link-impact">Impact</a>
            <a href="#contact" className="group flex items-center gap-2 rounded-full border border-[#a8c9b3]/50 px-4 py-2 text-sm text-[#f4f0e6] transition-colors hover:border-[#a8c9b3] hover:bg-[#a8c9b3] hover:text-[#26342c]" data-testid="link-contact-nav">
              Start a conversation <ArrowUpRight size={15} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>
          <button type="button" onClick={() => setMenuOpen((open) => !open)} className="rounded-full border border-[#a8c9b3]/40 p-2.5 md:hidden" aria-label={menuOpen ? 'Close menu' : 'Open menu'} data-testid="button-mobile-menu">
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </nav>
        {menuOpen && (
          <div className="relative z-10 border-b border-[#a8c9b3]/20 bg-[#26342c] px-8 pb-6 md:hidden">
            <div className="flex flex-col gap-4 pt-3">
              <a href="#process" onClick={closeMenu} className="py-2 text-lg" data-testid="link-mobile-process">Process</a>
              <a href="#materials" onClick={closeMenu} className="py-2 text-lg" data-testid="link-mobile-materials">Materials</a>
              <a href="#impact" onClick={closeMenu} className="py-2 text-lg" data-testid="link-mobile-impact">Impact</a>
              <a href="#contact" onClick={closeMenu} className="flex items-center gap-2 py-2 text-lg text-[#a8c9b3]" data-testid="link-mobile-contact">Start a conversation <ArrowUpRight size={17} /></a>
            </div>
          </div>
        )}

        <div className="section-shell relative grid min-h-[690px] items-center gap-12 pb-16 pt-16 lg:grid-cols-[1.05fr_.95fr] lg:gap-8 lg:pb-24 lg:pt-20">
          <div className="reveal max-w-[680px]">
            <div className="mb-8 flex flex-wrap items-center gap-x-4 gap-y-2">
              <SectionLabel light>Resource recovery, rethought</SectionLabel>
              <span className="text-eyebrow text-[#a8c9b3]/70">Based in the Pacific Northwest</span>
            </div>
            <h1 className="font-display max-w-[690px] text-[clamp(3.65rem,8vw,7.4rem)] font-medium leading-[.89] tracking-[-0.075em]">
              Keep the good stuff <em className="text-[#a8c9b3]">moving.</em>
            </h1>
            <p className="mt-8 max-w-[510px] text-lg leading-relaxed text-[#c9d4c9]">
              MindMetals gives discarded electronics a second direction — recovering the metals, components, and useful products already inside them.
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-5">
              <a href="#contact" className="group inline-flex items-center gap-3 rounded-full bg-[#d77a51] px-5 py-3.5 text-sm font-semibold text-[#f8f2e8] transition-transform hover:-translate-y-0.5" data-testid="link-hero-contact">
                Move your old electronics <ArrowRight size={17} className="transition-transform group-hover:translate-x-1" />
              </a>
              <a href="#process" className="inline-flex items-center gap-2 text-sm font-medium text-[#d4dfd5] transition-colors hover:text-[#a8c9b3]" data-testid="link-hero-process">
                See how it works <ArrowDownRight size={17} />
              </a>
            </div>
            <div className="mt-16 flex gap-9 border-t border-[#a8c9b3]/20 pt-5">
              <div><p className="font-mono-brand text-2xl text-[#f4f0e6]">01</p><p className="mt-1 text-xs text-[#a8c9b3]">Collect</p></div>
              <div className="h-8 w-px bg-[#a8c9b3]/25" />
              <div><p className="font-mono-brand text-2xl text-[#f4f0e6]">02</p><p className="mt-1 text-xs text-[#a8c9b3]">Separate</p></div>
              <div className="h-8 w-px bg-[#a8c9b3]/25" />
              <div><p className="font-mono-brand text-2xl text-[#f4f0e6]">03</p><p className="mt-1 text-xs text-[#a8c9b3]">Return</p></div>
            </div>
          </div>
          <div className="reveal delay-2 relative mx-auto w-full max-w-[510px] lg:ml-auto">
            <div className="relative aspect-square overflow-hidden rounded-[2rem] border border-[#a8c9b3]/25 bg-[#33473b] p-5 shadow-2xl">
              <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full border border-[#d9b66e]/20" />
              <div className="absolute -bottom-24 -left-12 h-72 w-72 rounded-full border border-[#a8c9b3]/20" />
              <svg viewBox="0 0 500 500" className="h-full w-full" role="img" aria-label="Abstract illustration of electronics becoming raw material">
                <defs>
                  <linearGradient id="copper" x1="0" x2="1"><stop stopColor="#d77a51" /><stop offset="1" stopColor="#e4b36c" /></linearGradient>
                  <linearGradient id="leaf" x1="0" x2="1"><stop stopColor="#a8c9b3" /><stop offset="1" stopColor="#668d75" /></linearGradient>
                </defs>
                <path d="M98 116h214c16 0 28 12 28 28v141c0 16-12 28-28 28H98c-16 0-28-12-28-28V144c0-16 12-28 28-28Z" fill="#202c26" stroke="#a8c9b3" strokeWidth="3" />
                <rect x="94" y="145" width="222" height="110" rx="5" fill="#3a5244" />
                <path d="M111 166h87M111 185h121M111 204h63M111 224h98" stroke="#a8c9b3" strokeWidth="5" strokeLinecap="round" opacity=".7" />
                <path d="m84 318 54-29 47 28 37-17 45 26-51 28-38-15-41 17-53-27Z" fill="url(#copper)" />
                <path d="M299 301c31-19 63-18 87 4-25 2-44 12-57 31-8-12-18-24-30-35Z" fill="url(#leaf)" />
                <path d="M375 298c-3-31 6-54 32-73-2 29-1 46 7 63-13 1-26 4-39 10Z" fill="#a8c9b3" opacity=".85" />
                <path d="M339 337c22 14 44 17 69 11-12 19-32 28-58 24-7-11-10-22-11-35Z" fill="#718f79" />
                <circle cx="364" cy="290" r="4" fill="#d9b66e" /><circle cx="401" cy="258" r="4" fill="#d77a51" />
                <path d="M350 280 312 248M329 302l-37-12M386 278l27-33" stroke="#d9b66e" strokeWidth="2" strokeDasharray="4 7" />
                <text x="71" y="395" fill="#c9d4c9" fontFamily="Space Mono" fontSize="10" letterSpacing="2">MATERIAL / IN MOTION</text>
                <text x="71" y="421" fill="#f4f0e6" fontFamily="Fraunces" fontSize="28">Nothing wasted.</text>
              </svg>
              <div className="absolute bottom-5 right-5 flex items-center gap-2 rounded-full bg-[#a8c9b3] px-3 py-2 text-xs font-semibold text-[#26342c]"><span className="h-1.5 w-1.5 rounded-full bg-[#26342c]" />System active</div>
            </div>
          </div>
        </div>
      </section>

      <section className="border-b border-[#d8d0c0] bg-[#eee9dd]">
        <div className="section-shell grid gap-8 py-14 md:grid-cols-[1.2fr_2fr] md:items-center">
          <p className="reveal text-eyebrow text-[#d77a51]">The material reality</p>
          <p className="reveal delay-1 font-display text-2xl leading-snug tracking-[-0.035em] text-[#26342c] md:text-[2.45rem]">
            The fastest path to a more resourceful future may already be sitting in a drawer.
          </p>
        </div>
      </section>

      <section id="why" className="section-shell grid gap-14 py-24 md:py-32 lg:grid-cols-[.8fr_1.2fr] lg:gap-24">
        <div className="reveal">
          <SectionLabel>Why this matters</SectionLabel>
          <h2 className="font-display mt-6 max-w-[500px] text-5xl leading-[.96] tracking-[-0.06em] text-[#26342c] md:text-6xl">
            A device’s last day is not its <span className="text-[#d77a51]">full story.</span>
          </h2>
        </div>
        <div className="reveal delay-1">
          <p className="max-w-[580px] text-xl leading-relaxed text-[#526058]">
            Electronics are dense little mines of copper, aluminum, gold, engineered plastics, and parts that still know how to do useful work. When they are treated as rubbish, that value disappears into a messy end-of-life.
          </p>
          <p className="mt-6 max-w-[580px] leading-relaxed text-[#68746c]">
            MindMetals works with businesses to make the next step clear: collect responsibly, recover what has value, and route every stream toward its most useful next life. Less extraction. More circulation.
          </p>
          <div className="mt-12 grid gap-8 border-t border-[#d8d0c0] pt-7 sm:grid-cols-2">
            <div className="flex gap-4"><Cpu size={23} strokeWidth={1.5} className="mt-1 text-[#d77a51]" /><div><h3 className="font-semibold text-[#26342c]">Complex by nature</h3><p className="mt-2 text-sm leading-relaxed text-[#68746c]">Modern devices combine dozens of material families in one small footprint.</p></div></div>
            <div className="flex gap-4"><RefreshCcw size={23} strokeWidth={1.5} className="mt-1 text-[#6f977b]" /><div><h3 className="font-semibold text-[#26342c]">Circular by choice</h3><p className="mt-2 text-sm leading-relaxed text-[#68746c]">Good recovery keeps finite materials in productive use for longer.</p></div></div>
          </div>
        </div>
      </section>

      <section id="process" className="bg-[#26342c] py-24 text-[#f4f0e6] md:py-32">
        <div className="section-shell">
          <div className="reveal flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div><SectionLabel light>Our process</SectionLabel><h2 className="font-display mt-6 max-w-[650px] text-5xl leading-[.95] tracking-[-0.06em] md:text-7xl">From old hardware<br /><em className="text-[#a8c9b3]">to useful matter.</em></h2></div>
            <p className="max-w-[250px] text-sm leading-relaxed text-[#b8c9bc]">A measured, traceable flow designed around the material — and the people handing it over.</p>
          </div>
          <div className="mt-20 grid gap-0 border-t border-[#a8c9b3]/25 md:grid-cols-4">
            {[
              { no: '01', icon: PackageCheck, title: 'Receive', copy: 'We map the material mix, logistics, and desired outcomes before a load moves.' },
              { no: '02', icon: Layers3, title: 'Prepare', copy: 'Devices are sorted, depolluted, and made ready for the right recovery route.' },
              { no: '03', icon: Factory, title: 'Recover', copy: 'Mechanical separation concentrates valuable metals and useful component streams.' },
              { no: '04', icon: Recycle, title: 'Return', copy: 'Recovered outputs move back into manufacturing and practical second lives.' },
            ].map(({ no, icon: Icon, title, copy }, index) => (
              <div key={no} className={`reveal delay-${index + 1} group border-b border-[#a8c9b3]/25 py-8 md:border-b-0 md:border-r md:px-7 md:first:pl-0 md:last:border-r-0`}>
                <div className="flex items-center justify-between"><span className="font-mono-brand text-sm text-[#d77a51]">{no}</span><Icon size={22} strokeWidth={1.4} className="text-[#a8c9b3] transition-transform group-hover:-translate-y-1 group-hover:rotate-6" /></div>
                <h3 className="mt-14 font-display text-3xl tracking-[-0.04em]">{title}</h3>
                <p className="mt-4 max-w-[220px] text-sm leading-relaxed text-[#b8c9bc]">{copy}</p>
                <div className="mt-8 h-1 w-8 bg-[#d77a51] transition-all group-hover:w-16" />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="materials" className="section-shell py-24 md:py-32">
        <div className="reveal flex flex-col justify-between gap-7 md:flex-row md:items-end">
          <div><SectionLabel>What comes back</SectionLabel><h2 className="font-display mt-6 max-w-[650px] text-5xl leading-[.95] tracking-[-0.06em] text-[#26342c] md:text-7xl">A better end<br />is a <span className="text-[#d77a51]">beginning.</span></h2></div>
          <p className="max-w-[300px] text-sm leading-relaxed text-[#68746c]">We focus on the useful, measurable outputs hiding inside retired electronics.</p>
        </div>
        <div className="mt-16 grid gap-4 lg:grid-cols-[1.35fr_1fr_1fr]">
          <article className="reveal delay-1 relative min-h-[420px] overflow-hidden rounded-2xl bg-[#d77a51] p-8 text-[#f8f2e8] lg:row-span-2">
            <div className="absolute -bottom-24 -right-16 h-80 w-80 rounded-full border border-[#f8f2e8]/25" />
            <div className="absolute right-8 top-9 font-mono-brand text-xs text-[#f8f2e8]/70">01 / CORE STREAM</div>
            <div className="relative mt-36 max-w-[320px]"><h3 className="font-display text-5xl leading-[.93] tracking-[-0.06em]">Copper<br />& conductors</h3><p className="mt-5 text-sm leading-relaxed text-[#f8f2e8]/80">A workhorse material for power, data, and the infrastructure that connects people.</p></div>
            <div className="absolute bottom-9 left-8 flex items-center gap-2 text-xs font-semibold"><span className="h-2 w-2 rounded-full bg-[#a8c9b3]" />Material value, retained</div>
          </article>
          <article className="reveal delay-2 min-h-[205px] rounded-2xl bg-[#dfe9dc] p-7 text-[#26342c] transition-transform hover:-translate-y-1">
            <div className="flex items-start justify-between"><span className="font-mono-brand text-xs text-[#66846f]">02 / NON-FERROUS</span><Sparkles size={20} strokeWidth={1.5} className="text-[#d77a51]" /></div>
            <h3 className="mt-14 font-display text-3xl tracking-[-0.04em]">Aluminum & steel</h3><p className="mt-2 text-sm leading-relaxed text-[#526058]">Strong, adaptable feedstock for products that need another round.</p>
          </article>
          <article className="reveal delay-3 min-h-[205px] rounded-2xl bg-[#e8dfca] p-7 text-[#26342c] transition-transform hover:-translate-y-1">
            <div className="flex items-start justify-between"><span className="font-mono-brand text-xs text-[#9c744e]">03 / COMPONENTS</span><ShieldCheck size={20} strokeWidth={1.5} className="text-[#d77a51]" /></div>
            <h3 className="mt-14 font-display text-3xl tracking-[-0.04em]">Useful parts</h3><p className="mt-2 text-sm leading-relaxed text-[#526058]">Tested components can stay in service instead of becoming scrap.</p>
          </article>
          <article className="reveal delay-2 min-h-[205px] rounded-2xl bg-[#354c3f] p-7 text-[#f4f0e6] transition-transform hover:-translate-y-1">
            <div className="flex items-start justify-between"><span className="font-mono-brand text-xs text-[#a8c9b3]">04 / DATA & CARE</span><RefreshCcw size={20} strokeWidth={1.5} className="text-[#d9b66e]" /></div>
            <h3 className="mt-14 font-display text-3xl tracking-[-0.04em]">A clear handoff</h3><p className="mt-2 text-sm leading-relaxed text-[#c9d4c9]">Material reporting that helps teams close the loop with confidence.</p>
          </article>
        </div>
      </section>

      <section id="impact" className="border-y border-[#d8d0c0] bg-[#e8dfca] py-24 md:py-32">
        <div className="section-shell">
          <div className="reveal grid gap-8 md:grid-cols-[1fr_1.6fr] md:items-end">
            <SectionLabel>Impact, in the open</SectionLabel>
            <h2 className="font-display text-4xl leading-[.98] tracking-[-0.055em] text-[#26342c] md:text-6xl">Progress is easier to trust when you can <span className="text-[#d77a51]">see the work.</span></h2>
          </div>
          <div className="mt-16 grid gap-0 border-y border-[#bdb29d] md:grid-cols-3">
            <div className="reveal delay-1 border-b border-[#bdb29d] py-8 md:border-b-0 md:border-r md:pr-8"><div className="font-mono-brand text-5xl tracking-[-0.08em] text-[#26342c]">4.8<span className="text-[#d77a51]">k</span></div><p className="mt-3 max-w-[220px] text-sm leading-relaxed text-[#68746c]">tonnes of electronics routed through recovery programs in our first operating years</p></div>
            <div className="reveal delay-2 border-b border-[#bdb29d] py-8 md:border-b-0 md:border-r md:px-8"><div className="font-mono-brand text-5xl tracking-[-0.08em] text-[#26342c]">72<span className="text-[#d77a51]">%</span></div><p className="mt-3 max-w-[220px] text-sm leading-relaxed text-[#68746c]">of incoming material directed toward metal recovery or component reuse</p></div>
            <div className="reveal delay-3 py-8 md:pl-8"><div className="font-mono-brand text-5xl tracking-[-0.08em] text-[#26342c]">18<span className="text-[#d77a51]">mo</span></div><p className="mt-3 max-w-[220px] text-sm leading-relaxed text-[#68746c]">average reporting window for a partner’s material story, from intake to output</p></div>
          </div>
          <div className="reveal mt-10 flex flex-col justify-between gap-5 text-xs text-[#68746c] md:flex-row"><span>Illustrative operating data · updated Q2 2024</span><span className="inline-flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-[#6f977b]" />Measured with partner intake records</span></div>
        </div>
      </section>

      <section id="contact" className="bg-[#a8c9b3] py-24 text-[#26342c] md:py-32">
        <div className="section-shell grid gap-14 lg:grid-cols-[1fr_.9fr] lg:gap-24">
          <div className="reveal">
            <SectionLabel>Let’s make a material plan</SectionLabel>
            <h2 className="font-display mt-7 max-w-[600px] text-6xl leading-[.9] tracking-[-0.07em] md:text-8xl">What’s sitting in your <em className="text-[#d77a51]">back room?</em></h2>
            <p className="mt-8 max-w-[480px] text-lg leading-relaxed text-[#43584b]">Tell us what you’re moving, where it is, and what a useful outcome looks like. We’ll reply with a practical next step.</p>
            <div className="mt-10 flex flex-wrap gap-5 text-sm text-[#43584b]"><span className="inline-flex items-center gap-2"><Mail size={16} /> hello@mindmetals.co</span><span className="inline-flex items-center gap-2"><MapPin size={16} /> Portland, Oregon</span></div>
          </div>
          <div className="reveal delay-2 rounded-2xl bg-[#f4f0e6] p-6 shadow-xl md:p-8">
            {sent ? (
              <div className="flex min-h-[410px] flex-col items-start justify-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#a8c9b3] text-[#26342c]"><Check size={24} /></div>
                <h3 className="font-display mt-7 text-4xl tracking-[-0.05em]">Message received.</h3>
                <p className="mt-4 max-w-[330px] leading-relaxed text-[#68746c]">Thanks for starting the conversation. A member of the MindMetals team will be in touch soon.</p>
                <button type="button" onClick={() => setSent(false)} className="mt-8 text-sm font-semibold text-[#d77a51] underline underline-offset-4" data-testid="button-send-another">Send another note</button>
              </div>
            ) : (
              <form onSubmit={submitContact} className="space-y-5" data-testid="form-contact">
                <div className="mb-7"><p className="text-eyebrow text-[#d77a51]">Start here</p><h3 className="font-display mt-3 text-3xl tracking-[-0.045em]">Bring us the tricky stuff.</h3></div>
                <label className="block"><span className="mb-2 block text-xs font-semibold text-[#526058]">Your name</span><input required name="name" type="text" placeholder="Alex Morgan" className="w-full rounded-lg border border-[#d8d0c0] bg-transparent px-4 py-3 text-sm outline-none transition-colors placeholder:text-[#9aa39b] focus:border-[#d77a51]" data-testid="input-contact-name" /></label>
                <label className="block"><span className="mb-2 block text-xs font-semibold text-[#526058]">Work email</span><input required name="email" type="email" placeholder="alex@company.com" className="w-full rounded-lg border border-[#d8d0c0] bg-transparent px-4 py-3 text-sm outline-none transition-colors placeholder:text-[#9aa39b] focus:border-[#d77a51]" data-testid="input-contact-email" /></label>
                <label className="block"><span className="mb-2 block text-xs font-semibold text-[#526058]">What are you moving?</span><select name="material" defaultValue="" className="w-full appearance-none rounded-lg border border-[#d8d0c0] bg-[#f4f0e6] px-4 py-3 text-sm outline-none focus:border-[#d77a51]" data-testid="select-contact-material"><option value="" disabled>Select a material stream</option><option>Retired IT equipment</option><option>Manufacturing electronics</option><option>Mixed devices</option><option>Not sure yet</option></select></label>
                <label className="block"><span className="mb-2 block text-xs font-semibold text-[#526058]">A little context <span className="font-normal text-[#9aa39b]">(optional)</span></span><textarea name="message" rows={3} placeholder="Volume, timing, location — whatever helps." className="w-full resize-none rounded-lg border border-[#d8d0c0] bg-transparent px-4 py-3 text-sm outline-none transition-colors placeholder:text-[#9aa39b] focus:border-[#d77a51]" data-testid="textarea-contact-message" /></label>
                <button type="submit" className="group mt-2 flex w-full items-center justify-center gap-3 rounded-lg bg-[#26342c] px-5 py-3.5 text-sm font-semibold text-[#f4f0e6] transition-colors hover:bg-[#354c3f]" data-testid="button-submit-contact">Send inquiry <ArrowUpRight size={17} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></button>
                <p className="text-center text-[11px] leading-relaxed text-[#7b887f]">No sales pitch, no mailing list. Just a thoughtful reply.</p>
              </form>
            )}
          </div>
        </div>
      </section>

      <footer className="bg-[#26342c] py-12 text-[#f4f0e6]">
        <div className="section-shell flex flex-col justify-between gap-8 md:flex-row md:items-end">
          <div><a href="#top" data-testid="link-footer-brand"><Mark inverse /></a><p className="mt-5 max-w-[270px] text-sm leading-relaxed text-[#a8b9aa]">Keeping resources in motion, one retired device at a time.</p></div>
          <div className="flex flex-col gap-3 text-sm text-[#c9d4c9] md:items-end"><div className="flex gap-5"><a href="#process" className="transition-colors hover:text-[#a8c9b3]" data-testid="link-footer-process">Process</a><a href="#materials" className="transition-colors hover:text-[#a8c9b3]" data-testid="link-footer-materials">Materials</a><a href="#impact" className="transition-colors hover:text-[#a8c9b3]" data-testid="link-footer-impact">Impact</a></div><span className="font-mono-brand text-[10px] text-[#778a7b]">© 2024 MINDMETALS / MATERIALS IN MOTION</span></div>
        </div>
      </footer>
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;